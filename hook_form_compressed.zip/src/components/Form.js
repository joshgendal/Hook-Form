import React, { useState } from "react";

const Form = (props) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPw, setConfirmPw] = useState("");

  return (
    <>
      <form onSubmit={() => {}}>
        <div>
          <label htmlFor="">First Name</label>
          <input type="text" onChange={(e) => setFirstName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="">Last Name</label>
          <input type="text" onChange={(e) => setLastName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="">Email</label>
          <input type="text" onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label htmlFor="">Password</label>
          <input type="text" onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div>
          <label htmlFor="">Confirm Password</label>
          <input type="text" onChange={(e) => setConfirmPw(e.target.value)} />
        </div>
      </form>

      <h2>Your Form Data</h2>

      <h3>First Name</h3>
      <span>{firstName}</span>
      <h3>Last Name</h3>
      <span>{lastName}</span>
      <h3>Email</h3>
      <span>{email}</span>
      <h3>Password</h3>
      <span>{password}</span>
      <h3>Confirm Password</h3>
      <span>{confirmPw}</span>
    </>
  );
};

export default Form;
